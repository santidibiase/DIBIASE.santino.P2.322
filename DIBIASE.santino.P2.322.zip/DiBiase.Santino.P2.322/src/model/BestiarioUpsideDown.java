package model;

import interfaces.CSVSerializable;
import interfaces.Condicion;
import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;



public class BestiarioUpsideDown<T extends CSVSerializable & Serializable & Comparable<T>> implements Serializable {

    
    private List<T> elementos = new ArrayList<>();
    public void agregar(T elem){
        elementos.add(elem);
    }

    public T obtener(int index) {
       return elementos.get(index);
    }

    public void eliminar(int index) {
        
        elementos.remove(index);
    
  }

    
    public List<T> filtrar(Condicion<T> condicion) {
        List<T> filtrados = new ArrayList<>();
        for (T elem : elementos) {
            if (condicion.test(elem)) {
                filtrados.add(elem);
            
            }
        }
        return filtrados;
   }

    public void ordenar() {
        Collections.sort(elementos);
    }

    public void ordenar(Comparator<T> comparator) {
        elementos.sort(comparator);
    }

    public void paraCadaElemento(Consumer<T> accion) {
        for (T elem : elementos) {
            accion.accept(elem);
        
        }
    }
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(elementos);
        }
    }

    
    @SuppressWarnings("unchecked")
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) ois.readObject();
        }
    }

    
    
    public void guardarEnCSV(String ruta) throws IOException{
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta)))  {
            for (T elem : elementos) {
                bw.write(elem.toCSV());
                bw.newLine();
            }
        
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> mapper) throws IOException {
        elementos.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
             String linea;
            while ((linea = br.readLine()) != null) {
              elementos.add(mapper.apply(linea));
            }
        }
    }

}
