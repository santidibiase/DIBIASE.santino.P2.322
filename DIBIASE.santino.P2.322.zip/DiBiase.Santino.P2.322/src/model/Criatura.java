package model;

import enums.TipoCriatura;
import interfaces.CSVSerializable;
import java.io.Serializable;

public class Criatura implements Comparable<Criatura>, CSVSerializable, Serializable {

    private final int id;
    private final String nombre;
    private final String origen;
    private final TipoCriatura tipo;

    public Criatura(int id, String nombre, String origen, TipoCriatura tipo){
        this.id = id;
        this.nombre = nombre;
        this.origen = origen;
        this.tipo = tipo;
    
    
    }

    public int getId(){return id;}
    
    public String getNombre(){return nombre;}
    
    public String getOrigen(){return origen;}
    
    public TipoCriatura getTipo() {return tipo;}

    @Override
    public int compareTo(Criatura o) {
        return Integer.compare(this.id, o.id);
    
    
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + origen + "," + tipo; }
    

    public static Criatura fromCSV(String linea) {
        String[] parts = linea.split(",");
        int id = Integer.parseInt(parts[0].trim());
        String nombre = parts[1].trim();
        String origen = parts[2].trim();
        TipoCriatura tipo = TipoCriatura.valueOf(parts[3].trim());
        return new Criatura(id, nombre, origen, tipo);
    }

    @Override
    public String toString() {
        return id +")" + nombre + " - " + origen + " - " + tipo;
    
    }



}
