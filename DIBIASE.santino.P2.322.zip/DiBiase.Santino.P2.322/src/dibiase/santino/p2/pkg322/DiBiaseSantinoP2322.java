package dibiase.santino.p2.pkg322;


import model.BestiarioUpsideDown;
import model.Criatura;
import enums.TipoCriatura;
import java.io.IOException;


public class DiBiaseSantinoP2322 {

    public static void main(String[] args){
        try {
           BestiarioUpsideDown<Criatura> bestiario = new BestiarioUpsideDown<>();

           bestiario.agregar(new Criatura(1, "Demogorgon", "Upside Down", TipoCriatura.DEMOGORGON));
           bestiario.agregar(new Criatura(2, "Demodog Juvenil", "Bosque de Hawkins", TipoCriatura.DEMODOG));
           bestiario.agregar(new Criatura(3, "Shadow Tendril", "Dimension Principal", TipoCriatura.SHADOW_MONSTER));
           bestiario.agregar(new Criatura(4, "Mind Flayer Spawn", "Upside Down", TipoCriatura.MIND_FLAYER_MINION));
           bestiario.agregar(new Criatura(5, "Murciélago del Upside Down", "Cueva Oscura", TipoCriatura.MURCIELAGO));

            System.out.println("Criaturas:");
            bestiario.paraCadaElemento(c -> System.out.println(c));  

            System.out.println("\nCriaturas tipo DEMODOG:");
            bestiario.filtrar(c -> c.getTipo() == TipoCriatura.DEMODOG)
                     .forEach(System.out::println);

            System.out.println("\nCriaturas que contienen 'shadow':");
            bestiario.filtrar(c -> c.getNombre().toLowerCase().contains("shadow"))
                     .forEach(System.out::println);
            System.out.println("\nCriaturas ordenadas por ID:");
            bestiario.ordenar();
            bestiario.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCriaturas ordenadas por nombre:");
            bestiario.ordenar((c1, c2) -> c1.getNombre().compareTo(c2.getNombre()));
            bestiario.paraCadaElemento(c -> System.out.println(c));

            bestiario.guardarEnArchivo("src/data/criaturas.dat");
            BestiarioUpsideDown<Criatura> cargado = new BestiarioUpsideDown<>();
            cargado.cargarDesdeArchivo("src/data/criaturas.dat");
            System.out.println("\nCriaturas cargadas desde archivo binario:");
            cargado.paraCadaElemento(System.out::println);

            bestiario.guardarEnCSV("src/data/criaturas.csv");
            cargado.cargarDesdeCSV("src/data/criaturas.csv", Criatura::fromCSV);

            System.out.println("\nCriaturas cargadas desde archivo CSV:");
            cargado.paraCadaElemento(System.out::println);

        }catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        
       }
  
    }
}
