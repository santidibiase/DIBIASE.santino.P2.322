package interfaces;

public interface Inventariable {
    String getInfoInventario();
}
