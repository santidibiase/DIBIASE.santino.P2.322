package interfaces;

public interface Condicion<T> {
    boolean test(T elem);
}
