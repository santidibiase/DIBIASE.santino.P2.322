package interfaces;

public interface CSVSerializable{
    String toCSV();
}
