package services;

import model.BestiarioUpsideDown;
import model.Criatura;
import enums.TipoCriatura;
import java.util.List;

public class Filtros{

    public static List<Criatura> porTipo(BestiarioUpsideDown<Criatura> bestiario, TipoCriatura tipo){
        return bestiario.filtrarPorTipo(tipo);
    
    }

    public static List<Criatura> nombreContiene(BestiarioUpsideDown<Criatura> bestiario, String palabra) {
        return bestiario.filtrarPorNombre(palabra);
  }
}
