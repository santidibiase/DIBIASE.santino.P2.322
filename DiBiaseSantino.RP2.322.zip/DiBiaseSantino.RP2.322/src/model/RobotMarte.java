package model;

import enums.TipoRobot;
import java.io.Serializable;



public class RobotMarte implements Comparable<RobotMarte>, Serializable {
    private final int id;
    private final String nombre;
    private final TipoRobot tipo;
    private final int nivelBateria;
    private final int anioFabricacion;
    private final double kmRecorridos;

    
    
    public RobotMarte(int id, String nombre, TipoRobot tipo, int nivelBateria,
                      int anioFabricacion, double kmRecorridos) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.nivelBateria = nivelBateria;
        this.anioFabricacion = anioFabricacion;
        this.kmRecorridos = kmRecorridos;
     }

    
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public TipoRobot getTipo() { return tipo; }
    public int getNivelBateria() { return nivelBateria; }
    public int getAnioFabricacion() { return anioFabricacion; }
    public double getKmRecorridos() { return kmRecorridos; }

    
    
    @Override
    public int compareTo(RobotMarte o){
        int cmp = Integer.compare(o.nivelBateria, this.nivelBateria);
        if (cmp != 0) return cmp;

        return Double.compare(o.kmRecorridos, this.kmRecorridos);
        }

    public static String toHeaderCSV() {
        return "id;nombre;tipo;nivelBateria;anioFabricacion;kmRecorridos";
    
    }
    
    

    public String toCSV() {
        return id + ";" + nombre + ";" + tipo + ";" + nivelBateria + ";" +
               anioFabricacion + ";" + kmRecorridos;}

    
    public static RobotMarte fromCSV(String linea) {
        String[] p = linea.split(";");
        return new RobotMarte(
                Integer.parseInt(p[0]),
                p[1],
                TipoRobot.valueOf(p[2]),
                Integer.parseInt(p[3]),
                Integer.parseInt(p[4]),
                Double.parseDouble(p[5])
         );
      
    
    }

    @Override
    public String toString() {
        return "RobotMarte{" +
                "id =" + id +
                ", nombre ='" + nombre + '\'' +
                ", tipo =" + tipo +
                ", nivelBateria=" + nivelBateria +
                ", anioFabricacion =" + anioFabricacion +
                ", kmRecorridos =" + kmRecorridos +
                ')';
    
   }


}


