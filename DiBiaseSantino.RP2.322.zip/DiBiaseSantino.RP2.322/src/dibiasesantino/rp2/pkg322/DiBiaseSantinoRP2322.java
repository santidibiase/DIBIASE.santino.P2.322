package dibiasesantino.rp2.pkg322;

import enums.TipoRobot;
import interfaces.Almacenable;
import java.util.List;
import model.RobotMarte;
import services.Inventario;

public class DiBiaseSantinoRP2322 {
    public static void main(String[] args) {
        try {
            Almacenable<RobotMarte> inv = new Inventario<>();

            inv.agregar(new RobotMarte(101, "Ares-1", TipoRobot.RECOLECTOR, 85, 2019, 123.5));
            inv.agregar(new RobotMarte(102, "Vulcan-7", TipoRobot.SENSORIAL, 40, 2020, 88.2));
            inv.agregar(new RobotMarte(103, "GeoMax", TipoRobot.GEOLOGICO, 25, 2017, 210.4));
            inv.agregar(new RobotMarte(104, "TopoTrack", TipoRobot.TOPOGRAFICO, 77, 2021, 156.0));
            inv.agregar(new RobotMarte(105, "HelperX", TipoRobot.ASISTENCIA, 50, 2018, 95.3));
            inv.agregar(new RobotMarte(106, "Ares-2", TipoRobot.RECOLECTOR, 33, 2016, 178.9));

            System.out.println("\n ===== Inventario Original =====");
            for (RobotMarte r : inv.obtenerTodos()) {
                System.out.println(r);
            }

            
            inv.ordenar();
            System.out.println("\n ===== Orden Natural =====");
            for (RobotMarte r : inv.obtenerTodos()) {
                System.out.println(r);
             }

            
            inv.ordenar((a, b)-> a.getNombre().compareToIgnoreCase(b.getNombre()));
            System.out.println("\n ===== Ordenados por Nombre =====");
            for (RobotMarte r : inv.obtenerTodos()) {
                System.out.println(r);
          }

           
            System.out.println("\n ===== Robots con Bateria < 30% =====");
            List<RobotMarte> criticos = inv.filtrar(r -> r.getNivelBateria() < 30);
            for (RobotMarte r : criticos) {
                System.out.println(r);
            
            
            }

            
            System.out.println("\n ===== Transformacion RECOLECTORES =====");
            List<RobotMarte> transformados = inv.transformar(r -> {
                if (r.getTipo() == TipoRobot.RECOLECTOR) {
                    double nuevosKm = r.getKmRecorridos() * 1.20;
                    return new RobotMarte(
                            
                        r.getId(),
                        r.getNombre(),
                        r.getTipo(),
                        r.getNivelBateria(),
                        r.getAnioFabricacion(),
                        nuevosKm );
            }
                
                return r;
        });

            for (RobotMarte r : transformados) {
                System.out.println(r);
            }

            
            int antiguos = inv.contar(r -> r.getAnioFabricacion() < 2018);
            System.out.println("\n  Robots fabricados antes de 2018: " + antiguos);

            
            inv.guardarEnBinario("src/data/robots.bin");
            inv.guardarEnCSV("src/data/robots.csv");
            inv.guardarEnJSON("src/data/robots.json");

            Almacenable<RobotMarte> invCSV = new Inventario<>();
            invCSV.cargarDesdeCSV("src/data/robots.csv", linea -> RobotMarte.fromCSV(linea));

            
            
            System.out.println("\n  =====Inventario cargado desde CSV=====");
            for (RobotMarte r : invCSV.obtenerTodos()) {
                System.out.println(r);
                }

            } catch (Exception e) {
            System.err.println(e.getMessage());
        }
  
    }
}
