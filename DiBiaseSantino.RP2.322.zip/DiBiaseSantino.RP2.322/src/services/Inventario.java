package services;

import interfaces.Almacenable;
import model.RobotMarte;
import java.io.*;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T extends Serializable> implements Almacenable<T> {
    private List<T> lista = new ArrayList<>();
    @Override
    public void agregar(T elemento){
        lista.add(elemento);
    
    }

    @Override
    
    public void eliminarSegun(Predicate<T> criterio) {
        
        Iterator<T> it = lista.iterator();
        while (it.hasNext()) {
           if (criterio.test(it.next())) {
                it.remove();
           }
      
        }
    }

    @Override
    
    public List<T> obtenerTodos(){
       
        return new ArrayList<>(lista);
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        for (T e : lista) 
            
           if (criterio.test(e)) return e;
        return null;
        
        
        
    }

    @Override
    public void ordenar() {
      
    Collections.sort((List) lista);
    }
    
    

    @Override
    public void ordenar(Comparator<T> comparador) {
        lista.sort(comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> r = new ArrayList<>();
        for (T e : lista)
            if (criterio.test(e)) r.add(e);
        return r;
}

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> r = new ArrayList<>();
        for (T e : lista)
            r.add(operador.apply(e));
        return r;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        int c = 0;
        for (T e : lista)
            if (criterio.test(e)) c++;
        return c;
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception{
        
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta));
        
        oos.writeObject(lista);
        oos.close();
    }

    @Override
    
    public void cargarDesdeBinario(String ruta) throws Exception {
        
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta));
        lista = (List<T>) ois.readObject();
        ois.close();
        
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        PrintWriter pw = new PrintWriter(new FileWriter(ruta));
        if (!lista.isEmpty()) {
            pw.println(RobotMarte.toHeaderCSV());
        }

        for (T e : lista) {
            RobotMarte r = (RobotMarte) e; 
            pw.println(r.toCSV());
            
        }   pw.close();
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        lista.clear();
        BufferedReader br = new BufferedReader(new FileReader(ruta));

        String linea = br.readLine(); 
        while ((linea = br.readLine()) != null) {
            lista.add(fromCSV.apply(linea));
        }   br.close();
    }

    @Override
    public void guardarEnJSON(String ruta) throws Exception {
        PrintWriter pw = new PrintWriter(new FileWriter(ruta));
        pw.println("[");
        for (int i = 0; i < lista.size(); i++) {
            pw.println("  \"" + lista.get(i).toString() + "\"" +
                    (i < lista.size() - 1 ? "," : ""));
       }    pw.println("]");      
            pw.close();
  
    }
}










